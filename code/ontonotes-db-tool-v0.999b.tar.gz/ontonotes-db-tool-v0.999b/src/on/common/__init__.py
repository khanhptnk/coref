"""
-------------------------------------------------
:mod:`on.common` -- Utility and Logging Functions
-------------------------------------------------

.. automodule:: on.common.util
.. automodule:: on.common.log

"""
